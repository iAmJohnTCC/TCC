using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Insetos : MonoBehaviour,Interagiveis
{
    [SerializeField] public GameObject[] Esconderijos = new GameObject [4];
    [SerializeField] Animator[] meusinsetos;
    [SerializeField] string[] Qualinseto;
    [SerializeField] string[] Localizacao;
    int B;
    Movimentacao Player;
    void Start()
    {
        Player = GameObject.Find("Player").GetComponent<Movimentacao>();
        Invoke(nameof(Trocaresconderijo),Random.Range(30f,60f));
    }

    

    void Trocaresconderijo()
    {
        if (Localizacao[B] != Player.Localizacao)
        {
            Esconderijos[B].GetComponent<BoxCollider2D>().enabled=true;
            int A = Random.Range(0, Qualinseto.Length);
            B = Random.Range(0, Esconderijos.Length);
            if (Localizacao[B] != Player.Localizacao)
            {
                Esconderijos[B].GetComponent<BoxCollider2D>().enabled = false;
                transform.position = Esconderijos[B].transform.position;
                for (int i = 0; i < meusinsetos.Length; i++)
                {
                    meusinsetos[i].Play(Qualinseto[A]);
                }

                Invoke(nameof(Trocaresconderijo), Random.Range(30f, 60f));
            }
            else
            {
                Invoke(nameof(Trocaresconderijo), Random.Range(3f, 8f));
            }
        }
        else
        {
            Invoke(nameof(Trocaresconderijo), Random.Range(3f, 8f));
        }
    }
    public void Interacao (Movimentacao player)
    {
        player.Textoguia.text = "Eu n�o vou me esconder aqui";
    }
}
