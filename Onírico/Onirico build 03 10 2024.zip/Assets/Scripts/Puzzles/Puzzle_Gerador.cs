using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puzzle_Gerador : MonoBehaviour
{    void Start()
    {
        
    }
    void Update()
    {
        
    }
}
