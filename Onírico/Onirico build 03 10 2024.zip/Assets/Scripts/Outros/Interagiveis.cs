using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Interagiveis
{
    public void Interacao(Movimentacao player);

}
