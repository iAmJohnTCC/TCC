using Microsoft.Unity.VisualStudio.Editor;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Notas : MonoBehaviour
{
    [SerializeField] public string [] Paginas;
    [SerializeField] public Sprite imagem;

  
}
