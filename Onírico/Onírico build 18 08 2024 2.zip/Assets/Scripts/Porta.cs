using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Porta : MonoBehaviour
{
    [SerializeField] public GameObject posicao;
    [SerializeField] public GameObject Bloqueio;
    public bool Aberto;
    public string Iten_desbloqueio;
    public string Localizacao;
    public string Andaratual;
    void Start()
    {
        
    }
    void Update()
    {
        
    }
    
}













































































//RiskOfRain�umJoga�oRecomendo